// Copyright (c) 2026 Robotiq, Inc.
//
// Licensed under the BSD-3-Clause license; see LICENSE for details.

#pragma once

#include <array>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <type_traits>

#include <Robotiq/detail/register_map.hpp>
#include <Robotiq/gripper/fault_status.hpp>

namespace Robotiq {

//! \ingroup gripper_status
//! gSTA — activation sequence state.
enum class ActivationState : uint8_t
{
   Reset = detail::rm::kActivationStateReset, //!< not activated; rACT is clear
   InProgress = detail::rm::kActivationStateInProgress, //!< activation handshake running
   Reserved = detail::rm::kActivationStateReserved, //!< unallocated pattern; not activated
   Complete = detail::rm::kActivationStateComplete, //!< activated; ready for motion commands
};

//! \ingroup gripper_status
//! gOBJ — object detection state.
enum class ObjectDetection : uint8_t
{
   Moving = detail::rm::kObjectMoving, //!< fingers in motion, or motion not yet requested
   DetectedWhileOpening = detail::rm::kObjectDetectedOpening, //!< stopped early while opening
   DetectedWhileClosing = detail::rm::kObjectDetectedClosing, //!< stopped early while closing
   AtRequestedPosition = detail::rm::kObjectAtRequestedPosition, //!< reached rPR with no object stop
};

//! \ingroup gripper_status
//! \brief The GRIPPER STATUS byte (byte 0 of the status block).
//!
//! This byte is decoded through named accessors: activated() and goToEnabled() answer single
//! flag bits, while activationState() and objectDetection() unpack
//! multi-bit fields into their own enums (ActivationState, ObjectDetection).
//!
//! \par Example
//! \snippet snippets.cpp gripper-status-flags
class GripperStatusFlags
{
public:
   //! \brief Synthesize a byte the gripper would have sent.
   //!
   //! For simulators and for exercising status handling without hardware.
   //! \param bits The raw GRIPPER STATUS byte.
   //! \return A GripperStatusFlags wrapping \p bits.
   [[nodiscard]] static constexpr GripperStatusFlags fromRaw(uint8_t bits)
   {
      GripperStatusFlags flags;
      flags._bits = bits;
      return flags;
   }

   //! \return gACT — the echo of the last-sent rACT (activation request).
   [[nodiscard]] bool activated() const { return (_bits & detail::rm::kActivationStatusMask) != 0; }

   //! \return gGTO — the echo of the last-sent rGTO (go-to request).
   [[nodiscard]] bool goToEnabled() const { return (_bits & detail::rm::kGoToEchoMask) != 0; }

   //! \return gSTA — where the activation handshake stands; see ActivationState.
   [[nodiscard]] ActivationState activationState() const
   {
      return static_cast<ActivationState>((_bits & detail::rm::kActivationStateMask)
                                          >> detail::rm::kActivationStateShift);
   }

   //! \return gOBJ — whether the fingers are moving or stopped on an object; see ObjectDetection.
   [[nodiscard]] ObjectDetection objectDetection() const
   {
      return static_cast<ObjectDetection>((_bits & detail::rm::kObjectDetectionMask)
                                          >> detail::rm::kObjectDetectionShift);
   }

   //! \return The raw GRIPPER STATUS byte.
   [[nodiscard]] uint8_t raw() const { return _bits; }

   //! \return true if both flag bytes are identical.
   [[nodiscard]] bool operator==(GripperStatusFlags other) const { return _bits == other._bits; }
   //! \return true if the flag bytes differ.
   [[nodiscard]] bool operator!=(GripperStatusFlags other) const { return _bits != other._bits; }

private:
   uint8_t _bits = 0;
};

static_assert(std::is_standard_layout_v<GripperStatusFlags> && std::is_trivially_copyable_v<GripperStatusFlags>
                 && sizeof(GripperStatusFlags) == 1,
              "GripperStatusFlags must be a single byte");

//! \ingroup status
//! \brief The gripper status block (gripper -> host), laid out byte for
//! byte as the instruction manual's block table.
//!
//! \par Example
//! \snippet snippets.cpp motion-settled-example
struct GripperStatus
{
   GripperStatusFlags gripperStatus; //!< byte 0 — GRIPPER STATUS
   uint8_t reserved1 = 0; //!< byte 1
   FaultStatus faultStatus; //!< byte 2 — FAULT STATUS (gFLT / kFLT)
   uint8_t positionRequestEcho = 0; //!< byte 3 — gPR
   uint8_t position = 0; //!< byte 4 — gPO: 0 open .. 255 closed
   uint8_t current = 0; //!< byte 5 — gCU (effort proxy)

   //! bytes 6..15
   std::array<uint8_t, detail::rm::kStatusBlockBytes - detail::rm::kStatusDocumentedBytes> reservedTail{};

   //! \return Raw block access, the manual's byte order. size() bytes wide.
   [[nodiscard]] const uint8_t* data() const { return reinterpret_cast<const uint8_t*>(this); }
   //! \overload
   [[nodiscard]] uint8_t* data() { return reinterpret_cast<uint8_t*>(this); }
   //! \return The width of the status block in bytes (16, per the manual).
   [[nodiscard]] static constexpr std::size_t size() { return detail::rm::kStatusBlockBytes; }
};

//! \cond DOXYGEN_EXCLUDE
[[nodiscard]] inline bool operator==(const GripperStatus& lhs, const GripperStatus& rhs)
{
   return std::memcmp(lhs.data(), rhs.data(), GripperStatus::size()) == 0;
}
[[nodiscard]] inline bool operator!=(const GripperStatus& lhs, const GripperStatus& rhs)
{
   return !(lhs == rhs);
}
//! \endcond

static_assert(std::is_standard_layout_v<GripperStatus> && std::is_trivially_copyable_v<GripperStatus>
                 && sizeof(GripperStatus) == detail::rm::kStatusBlockBytes,
              "GripperStatus must overlay the raw status block exactly");
} // namespace Robotiq
